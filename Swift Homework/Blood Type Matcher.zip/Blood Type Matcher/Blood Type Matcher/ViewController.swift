//
//  ViewController.swift
//  Blood Type Matcher
//
//  Created by Megan Wong on 10/25/17.
//  Copyright © 2017 Megan Wong. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

   @IBOutlet weak var pickBloodType: UIPickerView!
   @IBOutlet weak var answerLabel: UILabel!

   let compatible = IsCompatible(donor: "O-", recipient: "O-")

   // MARK:-
   // MARK: Picker Data Source Methods

   func numberOfComponents(in pickerView: UIPickerView) -> Int {
      return 2
   }

   func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
      return compatible.bloodTypes.count
   }

   // MARK:-
   // MARK: Picker Delegate Methods

   func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
      return compatible.bloodTypes[row]
   }

   func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
      if component == 0 {
         compatible.userDonor = compatible.bloodTypes[row]
      }
      else {
         compatible.userRecipient = compatible.bloodTypes[row]
      }
      if compatible.compatibility {
         answerLabel.textColor = UIColor.green
         answerLabel.text = "Yes!"
      }
      else {
         answerLabel.textColor = UIColor.red
         answerLabel.text = "No!"
      }
      answerLabel.isHidden = false
   }


   override func viewDidLoad() {
      super.viewDidLoad()
      pickerView(pickBloodType, didSelectRow: 0, inComponent: 0)
      // Do any additional setup after loading the view, typically from a nib.
   }

   override func didReceiveMemoryWarning() {
      super.didReceiveMemoryWarning()
      // Dispose of any resources that can be recreated.
   }


}

