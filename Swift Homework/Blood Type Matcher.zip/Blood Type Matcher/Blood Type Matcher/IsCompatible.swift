//
//  IsCompatible.swift
//  Blood Type Matcher
//
//  Created by Megan Wong on 10/25/17.
//  Copyright © 2017 Megan Wong. All rights reserved.
//

import Foundation

class IsCompatible {
   var userDonor: String
   var userRecipient: String
   let bloodTypes = ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"]

   var compatibility: Bool {
      get {
         if userDonor == userRecipient {
            return true
         }
         else if userDonor == "O-" {
            return true
         }
         else if userRecipient == "AB+" {
            return true
         }
         else if userDonor == "O+" && userRecipient == "A+" {
            return true
         }
         else if userDonor == "A-" && userRecipient == "A+" {
            return true
         }
         else if userDonor == "O+" && userRecipient == "B+" {
            return true
         }
         else if userDonor == "B-" && userRecipient == "B+" {
            return true
         }
         else if userDonor == "A-" && userRecipient == "AB-" {
            return true
         }
         else if userDonor == "B-" && userRecipient == "AB-" {
            return true
         }
         else {
            return false
         }
      }
   }

   init(donor: String, recipient: String) {
      userDonor = donor
      userRecipient = recipient
   }
}
