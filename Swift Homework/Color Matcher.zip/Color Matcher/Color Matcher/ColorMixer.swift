//
//  ColorMixer.swift
//  Color Matcher
//
//  Created by Megan Wong on 10/11/17.
//  Copyright © 2017 Megan Wong. All rights reserved.
//

import Foundation
import UIKit
import GameKit

class ColorMixer {
   let randGen = GKRandomSource()
   var userRed: Float
   var userGreen: Float
   var userBlue: Float
   var randomRed: Float
   var randomGreen: Float
   var randomBlue: Float

   var userMixture: UIColor {
      get {
         return UIColor(red: CGFloat(userRed), green: CGFloat(userGreen), blue: CGFloat(userBlue), alpha: 1)
      }
   }

   var userRedSlider: UIColor {
      get {
         return UIColor(red: CGFloat(userRed), green: 0, blue: 0, alpha: 1)
      }
   }

   var userGreenSlider: UIColor {
      get {
         return UIColor(red: 0, green: CGFloat(userGreen), blue: 0, alpha: 1)
      }
   }

   var userBlueSlider: UIColor {
      get {
         return UIColor(red: 0, green: 0, blue: CGFloat(userBlue), alpha: 1)
      }
   }

   var randomMixture: UIColor {
      get {
         randomRed = randGen.nextUniform()
         randomGreen = randGen.nextUniform()
         randomBlue = randGen.nextUniform()
         return UIColor(red: CGFloat(randomRed), green: CGFloat(randomGreen), blue: CGFloat(randomBlue), alpha: 1)
      }
   }

   func setUserColors(red: Float, green: Float, blue: Float) {
      userRed = red
      userGreen = green
      userBlue = blue
   }

   init () {
      userRed = 0.5
      userGreen = 0.5
      userBlue = 0.5
      randomRed = 0
      randomGreen = 0
      randomBlue = 0
   }
}
