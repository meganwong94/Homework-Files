//
//  ViewController.swift
//  Color Matcher
//
//  Created by Megan Wong on 10/4/17.
//  Copyright © 2017 Megan Wong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   @IBOutlet weak var colorLabel: UILabel!
   @IBOutlet weak var matchLabel: UILabel!
   @IBOutlet weak var redSlider: UISlider!
   @IBOutlet weak var redSliderLabel: UILabel!
   @IBOutlet weak var greenSliderLabel: UILabel!
   @IBOutlet weak var greenSlider: UISlider!
   @IBOutlet weak var blueSlider: UISlider!
   @IBOutlet weak var blueSliderLabel: UILabel!

   var colorMixer = ColorMixer()

   override func viewDidLoad() {
      super.viewDidLoad()
      resetButton()
      // Do any additional setup after loading the view, typically from a nib.
   }

   @IBAction func sliderMoved() {
      matchLabel.text = ""
      let red = redSlider.value
      let blue = blueSlider.value
      let green = greenSlider.value
      colorMixer.setUserColors(red: red, green: green, blue: blue)
      matchLabel.backgroundColor = colorMixer.userMixture

      redSlider.backgroundColor = colorMixer.userRedSlider
      redSliderLabel.text = String(format: "%.3f", red)

      greenSlider.backgroundColor = colorMixer.userGreenSlider
      greenSliderLabel.text = String(format: "%.3f", green)

      blueSlider.backgroundColor = colorMixer.userBlueSlider
      blueSliderLabel.text = String(format: "%.3f", blue)
   }

   @IBAction func resetButton() {
      colorLabel.backgroundColor = colorMixer.randomMixture
      redSlider.value = 0.5
      blueSlider.value = 0.5
      greenSlider.value = 0.5
      sliderMoved()
   }

   @IBAction func showButton() {
      let roundRed = String(format: "%.3f", colorMixer.randomRed)
      let roundGreen = String(format: "%.3f", colorMixer.randomGreen)
      let roundBlue = String(format: "%.3f", colorMixer.randomBlue)
      let ac = UIAlertController(title: "Random Values:", message: "Red: \(roundRed)\nGreen: \(roundGreen)\nBlue: \(roundBlue)", preferredStyle: .alert)
      ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
      present(ac, animated: true)
   }

   override func didReceiveMemoryWarning() {
      super.didReceiveMemoryWarning()
   }
}

